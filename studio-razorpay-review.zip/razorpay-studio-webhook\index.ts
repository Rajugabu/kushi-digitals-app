import { type SupabaseClient } from "npm:@supabase/supabase-js@2";
import {
  fetchRazorpayPayment,
  getRazorpayApiConfig,
  getRazorpayWebhookSecret,
  safeProviderFailure,
  sha256Hex,
  verifyWebhookSignature,
} from "../_shared/razorpay.ts";
import {
  createStudioPaymentAdminClient,
  getSupabasePaymentEnvironment,
  jsonPaymentResponse,
  logSafeDatabaseError,
  normalizeStudioPaymentError,
  StudioPaymentRequestError,
} from "../_shared/studio-payment.ts";

type WebhookPayload = {
  event?: string;
  payload?: {
    payment?: { entity?: Record<string, unknown> };
    order?: { entity?: Record<string, unknown> };
    refund?: { entity?: Record<string, unknown> };
    dispute?: { entity?: Record<string, unknown> };
  };
};

type PurchaseRecord = {
  id: string;
  user_id: string;
  status: string;
  amount_paise_snapshot: number;
  currency_snapshot: string;
  razorpay_order_id: string;
  razorpay_payment_id: string | null;
};

const EVENT_ID_PATTERN = /^[A-Za-z0-9_.:-]+$/;
const RELEVANT_CAPTURE_EVENTS = new Set([
  "payment.captured",
  "order.paid",
]);
const REFUND_REVIEW_EVENTS = new Set([
  "refund.created",
  "refund.processed",
  "payment.dispute.created",
  "payment.dispute.won",
  "payment.dispute.lost",
]);

function safeString(value: unknown, maximum = 100) {
  return typeof value === "string" ? value.trim().slice(0, maximum) : "";
}

function getPaymentEntity(payload: WebhookPayload) {
  return payload.payload?.payment?.entity || {};
}

function getOrderEntity(payload: WebhookPayload) {
  return payload.payload?.order?.entity || {};
}

function getPaymentId(payload: WebhookPayload) {
  const payment = getPaymentEntity(payload);
  const refund = payload.payload?.refund?.entity || {};
  const dispute = payload.payload?.dispute?.entity || {};

  return safeString(
    payment.id || refund.payment_id || dispute.payment_id,
  );
}

function getOrderId(payload: WebhookPayload) {
  const payment = getPaymentEntity(payload);
  const order = getOrderEntity(payload);

  return safeString(payment.order_id || order.id);
}

async function updateWebhookEvent(
  adminClient: SupabaseClient,
  eventId: string,
  values: Record<string, unknown>,
) {
  const { error } = await adminClient
    .from("studio_payment_webhook_events")
    .update(values)
    .eq("event_id", eventId);

  if (error) {
    logSafeDatabaseError("webhook event update", error);
  }
}

async function claimWebhookEvent(
  adminClient: SupabaseClient,
  input: {
    eventId: string;
    eventType: string;
    orderId: string | null;
    paymentId: string | null;
    payloadHash: string;
  },
) {
  const { error } = await adminClient
    .from("studio_payment_webhook_events")
    .insert({
      event_id: input.eventId,
      event_type: input.eventType,
      razorpay_order_id: input.orderId,
      razorpay_payment_id: input.paymentId,
      payload_sha256: input.payloadHash,
      processing_status: "processing",
    });

  if (!error) {
    return { duplicate: false, finished: false };
  }

  if (error.code !== "23505") {
    logSafeDatabaseError("webhook event insert", error);
    throw new StudioPaymentRequestError(
      "WEBHOOK_EVENT_SAVE_FAILED",
      "The webhook event could not be recorded.",
      500,
      true,
    );
  }

  const { data: existing, error: existingError } = await adminClient
    .from("studio_payment_webhook_events")
    .select("payload_sha256, processing_status")
    .eq("event_id", input.eventId)
    .maybeSingle();

  if (existingError || !existing) {
    logSafeDatabaseError("duplicate webhook query", existingError);
    throw new StudioPaymentRequestError(
      "WEBHOOK_EVENT_QUERY_FAILED",
      "The webhook event state could not be checked.",
      500,
      true,
    );
  }

  if (existing.payload_sha256 !== input.payloadHash) {
    throw new StudioPaymentRequestError(
      "WEBHOOK_EVENT_HASH_CONFLICT",
      "The webhook event ID conflicts with an earlier payload.",
      409,
    );
  }

  if (["processed", "ignored"].includes(existing.processing_status)) {
    return { duplicate: true, finished: true };
  }

  await updateWebhookEvent(adminClient, input.eventId, {
    processing_status: "processing",
    error_code: null,
    error_message: null,
    processed_at: null,
  });

  return { duplicate: true, finished: false };
}

async function findPurchaseByOrder(
  adminClient: SupabaseClient,
  orderId: string,
) {
  const { data, error } = await adminClient
    .from("studio_credit_purchases")
    .select(
      "id, user_id, status, amount_paise_snapshot, currency_snapshot, razorpay_order_id, razorpay_payment_id",
    )
    .eq("razorpay_order_id", orderId)
    .maybeSingle<PurchaseRecord>();

  if (error) {
    logSafeDatabaseError("webhook purchase query", error);
    throw new StudioPaymentRequestError(
      "WEBHOOK_PURCHASE_QUERY_FAILED",
      "The Studio purchase could not be checked.",
      500,
      true,
    );
  }

  return data;
}

Deno.serve(async (request) => {
  if (request.method !== "POST") {
    return jsonPaymentResponse(request, {
      success: false,
      code: "METHOD_NOT_ALLOWED",
      message: "Method not allowed.",
    }, 405, false);
  }

  let adminClient: SupabaseClient | null = null;
  let eventId = "";
  let eventClaimed = false;

  try {
    const signature = request.headers.get("x-razorpay-signature")?.trim() || "";
    eventId = request.headers.get("x-razorpay-event-id")?.trim() || "";
    const rawBody = await request.text();
    const webhookSecret = getRazorpayWebhookSecret();
    const signatureValid = await verifyWebhookSignature(
      rawBody,
      signature,
      webhookSecret,
    );

    if (!signatureValid) {
      throw new StudioPaymentRequestError(
        "INVALID_WEBHOOK_SIGNATURE",
        "Webhook signature is invalid.",
        401,
      );
    }

    if (
      !eventId ||
      eventId.length > 200 ||
      !EVENT_ID_PATTERN.test(eventId)
    ) {
      throw new StudioPaymentRequestError(
        "INVALID_WEBHOOK_EVENT_ID",
        "A valid Razorpay webhook event ID is required.",
        400,
      );
    }

    const payloadHash = await sha256Hex(rawBody);
    const { supabaseUrl, serviceRoleKey } = getSupabasePaymentEnvironment();
    adminClient = createStudioPaymentAdminClient(
      supabaseUrl,
      serviceRoleKey,
    );

    let payload: WebhookPayload;

    try {
      payload = JSON.parse(rawBody) as WebhookPayload;
    } catch {
      await claimWebhookEvent(adminClient, {
        eventId,
        eventType: "malformed",
        orderId: null,
        paymentId: null,
        payloadHash,
      });
      eventClaimed = true;
      throw new StudioPaymentRequestError(
        "MALFORMED_WEBHOOK_PAYLOAD",
        "Webhook payload is malformed.",
        400,
      );
    }

    const eventType = safeString(payload.event);

    if (!eventType) {
      await claimWebhookEvent(adminClient, {
        eventId,
        eventType: "malformed",
        orderId: null,
        paymentId: null,
        payloadHash,
      });
      eventClaimed = true;
      throw new StudioPaymentRequestError(
        "MALFORMED_WEBHOOK_PAYLOAD",
        "Webhook event type is missing.",
        400,
      );
    }

    let paymentId = getPaymentId(payload);
    let orderId = getOrderId(payload);
    const claim = await claimWebhookEvent(adminClient, {
      eventId,
      eventType,
      orderId: /^order_[A-Za-z0-9]+$/.test(orderId) ? orderId : null,
      paymentId: /^pay_[A-Za-z0-9]+$/.test(paymentId) ? paymentId : null,
      payloadHash,
    });
    eventClaimed = true;

    if (claim.finished) {
      return jsonPaymentResponse(request, {
        success: true,
        duplicate: true,
        status: "already_processed",
      }, 200, false);
    }

    if (
      !RELEVANT_CAPTURE_EVENTS.has(eventType) &&
      eventType !== "payment.failed" &&
      !REFUND_REVIEW_EVENTS.has(eventType)
    ) {
      await updateWebhookEvent(adminClient, eventId, {
        processing_status: "ignored",
        processed_at: new Date().toISOString(),
      });
      return jsonPaymentResponse(request, {
        success: true,
        status: "ignored",
      }, 200, false);
    }

    const razorpayConfig = getRazorpayApiConfig();

    if (REFUND_REVIEW_EVENTS.has(eventType)) {
      if (!/^pay_[A-Za-z0-9]+$/.test(paymentId)) {
        throw new StudioPaymentRequestError(
          "WEBHOOK_PAYMENT_ID_REQUIRED",
          "The refund or dispute webhook has no valid payment ID.",
          400,
        );
      }

      const payment = await fetchRazorpayPayment(razorpayConfig, paymentId);
      orderId = payment.order_id;
      const purchase = await findPurchaseByOrder(adminClient, orderId);

      if (!purchase) {
        await updateWebhookEvent(adminClient, eventId, {
          razorpay_order_id: orderId,
          razorpay_payment_id: paymentId,
          processing_status: "ignored",
          processed_at: new Date().toISOString(),
        });
        return jsonPaymentResponse(request, {
          success: true,
          status: "ignored",
        }, 200, false);
      }

      const { error: reviewError } = await adminClient
        .from("studio_credit_purchases")
        .update({
          status: "refund_review",
          failure_code: "REFUND_OR_DISPUTE_REVIEW",
          failure_message: "A Razorpay refund or dispute requires administrator review.",
          provider_metadata: {
            review_event_type: eventType,
          },
        })
        .eq("id", purchase.id);

      if (reviewError) {
        logSafeDatabaseError("refund review update", reviewError);
        throw new StudioPaymentRequestError(
          "REFUND_REVIEW_SAVE_FAILED",
          "The payment review status could not be saved.",
          500,
          true,
        );
      }

      await updateWebhookEvent(adminClient, eventId, {
        razorpay_order_id: orderId,
        razorpay_payment_id: paymentId,
        processing_status: "processed",
        processed_at: new Date().toISOString(),
      });
      return jsonPaymentResponse(request, {
        success: true,
        status: "refund_review",
      }, 200, false);
    }

    if (
      !/^order_[A-Za-z0-9]+$/.test(orderId) ||
      !/^pay_[A-Za-z0-9]+$/.test(paymentId)
    ) {
      throw new StudioPaymentRequestError(
        "MALFORMED_PAYMENT_WEBHOOK",
        "The payment webhook is missing valid order or payment references.",
        400,
      );
    }

    const purchase = await findPurchaseByOrder(adminClient, orderId);

    if (!purchase) {
      await updateWebhookEvent(adminClient, eventId, {
        processing_status: "ignored",
        processed_at: new Date().toISOString(),
      });
      return jsonPaymentResponse(request, {
        success: true,
        status: "ignored",
      }, 200, false);
    }

    if (
      RELEVANT_CAPTURE_EVENTS.has(eventType) &&
      purchase.status === "refund_review"
    ) {
      await updateWebhookEvent(adminClient, eventId, {
        processing_status: "ignored",
        error_code: "PURCHASE_IN_REFUND_REVIEW",
        error_message: "Captured event was not fulfilled because the purchase requires refund review.",
        processed_at: new Date().toISOString(),
      });
      return jsonPaymentResponse(request, {
        success: true,
        status: "refund_review",
      }, 200, false);
    }

    if (eventType === "payment.failed") {
      const paymentEntity = getPaymentEntity(payload);
      const failure = safeProviderFailure({
        error_code: safeString(paymentEntity.error_code),
        error_description: safeString(paymentEntity.error_description, 300),
      });
      const { error: failureError } = await adminClient
        .from("studio_credit_purchases")
        .update({
          status: "failed",
          failure_code: failure.code,
          failure_message: failure.message,
          provider_metadata: { payment_status: "failed" },
        })
        .eq("id", purchase.id)
        .in("status", ["created", "order_created", "capture_pending", "failed"]);

      if (failureError) {
        logSafeDatabaseError("failed webhook update", failureError);
        throw new StudioPaymentRequestError(
          "FAILED_PAYMENT_SAVE_FAILED",
          "The failed payment status could not be saved.",
          500,
          true,
        );
      }

      await updateWebhookEvent(adminClient, eventId, {
        processing_status: "processed",
        processed_at: new Date().toISOString(),
      });
      return jsonPaymentResponse(request, {
        success: true,
        status: "failed",
      }, 200, false);
    }

    const payment = await fetchRazorpayPayment(razorpayConfig, paymentId);

    if (
      payment.id !== paymentId ||
      payment.order_id !== purchase.razorpay_order_id ||
      Number(payment.amount) !== Number(purchase.amount_paise_snapshot) ||
      payment.currency !== purchase.currency_snapshot ||
      payment.currency !== "INR" ||
      payment.status !== "captured"
    ) {
      throw new StudioPaymentRequestError(
        "WEBHOOK_PAYMENT_MISMATCH",
        "The captured payment does not match the stored Studio purchase.",
        409,
      );
    }

    const { data: fulfillment, error: fulfillmentError } =
      await adminClient.rpc("fulfill_studio_credit_purchase", {
        p_purchase_id: purchase.id,
        p_user_id: purchase.user_id,
        p_razorpay_order_id: purchase.razorpay_order_id,
        p_razorpay_payment_id: payment.id,
        p_amount_paise: Number(payment.amount),
        p_currency: payment.currency,
        p_source: "webhook",
      });

    if (fulfillmentError || fulfillment?.status !== "credited") {
      logSafeDatabaseError("webhook fulfillment RPC", fulfillmentError);
      throw new StudioPaymentRequestError(
        "WEBHOOK_FULFILLMENT_FAILED",
        "The captured Studio payment could not be fulfilled yet.",
        500,
        true,
      );
    }

    await updateWebhookEvent(adminClient, eventId, {
      processing_status: "processed",
      processed_at: new Date().toISOString(),
    });

    return jsonPaymentResponse(request, {
      success: true,
      status: "credited",
      idempotent: Boolean(fulfillment.idempotent),
    }, 200, false);
  } catch (error) {
    const normalized = normalizeStudioPaymentError(error);

    if (adminClient && eventId && eventClaimed) {
      await updateWebhookEvent(adminClient, eventId, {
        processing_status: "failed",
        error_code: normalized.code.slice(0, 100),
        error_message: normalized.message.slice(0, 500),
        processed_at: new Date().toISOString(),
      });
    }

    console.error("[razorpay-studio-webhook]", {
      code: normalized.code,
      status: normalized.status,
      eventId: eventId ? `${eventId.slice(0, 12)}...` : null,
    });

    return jsonPaymentResponse(request, {
      success: false,
      code: normalized.code,
      message: normalized.message,
      retryable: normalized.retryable,
    }, normalized.status, false);
  }
});
