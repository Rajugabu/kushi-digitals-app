# Studio AI generation setup

The `/studio` frontend sends the selected style ID, ratio, and one or two source files as multipart form data to the `generate-studio-design` Supabase Edge Function. A verified Supabase user session is required. Source files are sent directly to the configured provider and are not placed in a public bucket. The generated output is stored in the private `studio-results` bucket and returned through short-lived signed preview and download URLs.

## Apply database and Storage setup

Apply the migration before deploying the function:

```bash
supabase db push
```

The migration creates:

- `public.studio_generations`, with authenticated-user ownership and job status metadata for new credit-backed requests.
- `public.studio_credit_accounts` and `public.studio_credit_transactions`, which are isolated from the monetary earnings wallet.
- Service-role-only atomic reserve, finalize, release, reconciliation, and manual-add credit functions.
- A private `studio-results` Storage bucket.
- An authenticated read policy restricted to each user's top-level output folder. The Edge Function uses the service role only on the server and creates signed URLs for immediate Studio previews.

Input photos are not stored by this implementation. The `source_photo_1_path` and `source_photo_2_path` columns are reserved for a future private-input workflow if a different provider requires URL-based inputs.

## Configure Edge Function secrets

Required:

```bash
supabase secrets set OPENAI_API_KEY=your_server_side_key
```

Recommended production configuration:

```bash
supabase secrets set STUDIO_ALLOWED_ORIGINS=https://your-domain.example
supabase secrets set STUDIO_RATE_LIMIT_SALT=replace_with_a_long_random_value
```

Optional configuration:

```bash
supabase secrets set STUDIO_AI_PROVIDER=openai
supabase secrets set OPENAI_IMAGE_MODEL=gpt-image-2
supabase secrets set STUDIO_PROVIDER_TIMEOUT_MS=240000
supabase secrets set STUDIO_SIGNED_URL_SECONDS=3600
supabase secrets set STUDIO_RATE_LIMIT_MAX_REQUESTS=3
supabase secrets set STUDIO_RATE_LIMIT_WINDOW_MINUTES=15
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` are supplied to hosted Edge Functions by Supabase. Never copy `OPENAI_API_KEY` or the service-role key into the Vite environment or React source.

For multiple production origins, use a comma-separated `STUDIO_ALLOWED_ORIGINS` value. When the variable is omitted, the function returns permissive CORS headers for setup compatibility; configure it before production launch.

## Deploy

```bash
supabase functions deploy generate-studio-design
```

The function requires the caller's user JWT and verifies it again with `auth.getUser()` before creating a generation. The service-role key, provider key, trusted prompts, credit price, database writes, and Storage writes remain server-side.

## Request contract

`POST /functions/v1/generate-studio-design`

Content type: `multipart/form-data`

- `styleId`: an ID recognized by the server-side preset map.
- `ratio`: a ratio allowed by that preset.
- `photo1`: required JPG, JPEG, PNG, or WEBP, maximum 20 MB.
- `photo2`: required only for two-image presets, maximum 20 MB.

Credit amounts are never accepted from the browser. The trusted server preset charges 3 credits for every one-photo style and 4 credits for every two-photo style. One credit is displayed as ₹13.

The server verifies the declared MIME type and image file signature. Browser-provided prompts, provider models, prices, file paths, and output URLs are never trusted.

Successful response:

```json
{
  "success": true,
  "generationId": "uuid",
  "status": "completed",
  "outputUrl": "short-lived signed preview URL",
  "downloadUrl": "short-lived signed attachment URL",
  "outputPath": "private storage path",
  "outputUrlExpiresAt": "ISO timestamp",
  "styleId": "digital-painting-forest-green",
  "ratio": "2:3",
  "createdAt": "ISO timestamp",
  "creditsCharged": 3,
  "availableCredits": 7,
  "metadata": {
    "provider": "openai",
    "model": "gpt-image-2",
    "width": 2336,
    "height": 3504,
    "format": "png",
    "generationMode": "single_portrait_style",
    "upscale": {
      "requested": true,
      "applied": false,
      "status": "not_configured"
    }
  }
}
```

Error response:

```json
{
  "success": false,
  "generationId": null,
  "code": "PROVIDER_NOT_CONFIGURED",
  "message": "Real AI generation is not configured yet. Add the server-side provider secret and try again.",
  "retryable": false
}
```

## Provider and preset architecture

Public display configuration lives in `src/config/studioStyles.js`. It exposes only a preset key and logical generation mode. Trusted prompts, file counts, allowed ratios, quality settings, and output instructions live in `supabase/functions/_shared/style-presets.ts`.

The provider interface is defined in `supabase/functions/_shared/providers/types.ts`. `openai-image.ts` is the first adapter. A future provider can implement the same `ImageProvider` interface and be selected in `providers/index.ts` without changing React.

The current adapter uses a synchronous image-edit request, so frontend polling is not used. The function returns only after the provider output has been saved and both signed URLs exist.

## Upscaling and credits

The Edge Function contains an explicit upscale extension point between provider generation and Storage upload. No upscaler is configured yet, and the response says `applied: false`.

Each request creates a new generation row, then atomically reserves the trusted credit cost before provider construction or the OpenAI request. A completed provider call, Storage upload, signed-link creation, and generation record update are followed by atomic finalization. Any failure before finalization attempts the idempotent release function and removes an unfinalized output only after the database confirms release. If release cannot be confirmed, the generation remains failed with reserved credits and returns `STUDIO_CREDIT_REFUND_PENDING` so `reconcile_studio_generation_credits` can safely release them later. Regenerate starts a new generation and therefore charges again.

The OpenAI provider timeout is 240 seconds. The installed `@supabase/functions-js` 2.110.7 client documents and implements the `timeout` invoke option; the frontend allows 330 seconds for upload, provider work, Storage, database finalization, and response overhead. A browser timeout, lost connection, or page navigation only stops the browser from waiting. It does not prove that the backend generation stopped, and it must not be treated as a cancellation or automatic refund.

Authenticated users receive SELECT-only access to their own Studio credit account and transactions through RLS. The mutation functions are revoked from `public`, `anon`, and `authenticated`, and granted only to `service_role`. `wallet_accounts` and `wallet_transactions` remain the separate monetary earnings/withdrawal system.

The `manual_add` mode of `add_studio_credits` is for controlled testing and audited administrative grants only. Supply a unique admin-event idempotency key so retries cannot add credits twice.

Customer credit purchases require a server-side Razorpay webhook that verifies the webhook signature, payment status, currency, amount, and provider event/payment ID before calling the service-role credit function with an idempotency key. Never credit a Studio account from a frontend callback, redirect parameter, or other unverified client payment response.

## Local verification

```bash
npm test
npm run lint
npm run build
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/studio_credit_security_checks.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/studio_credit_behavior_checks.sql
```
